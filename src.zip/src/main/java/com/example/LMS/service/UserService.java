package com.example.LMS.service;

import com.example.LMS.dto.request.UserListRequest;
import com.example.LMS.dto.response.UserResponse;
import com.example.LMS.entity.model.User;
import com.example.LMS.entity.model.UserProfile;
import com.example.LMS.exception.CustomException;
import com.example.LMS.repository.UserProfileRepository;
import com.example.LMS.repository.UserRepository;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final UserProfileRepository userProfileRepository;

    // ============================================================
    // DANH SÁCH NGƯỜI DÙNG
    // ============================================================
    public Page<UserResponse> getUsers(UserListRequest request) {

        // 1. Tạo Pageable (phân trang + sắp xếp)
        Sort sort = request.getSortDirection().equalsIgnoreCase("asc")
                ? Sort.by(request.getSortBy()).ascending()
                : Sort.by(request.getSortBy()).descending();

        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), sort);

        // 2. Xây dựng Specification (dynamic filter)
        Specification<User> spec = buildSpecification(request);

        // 3. Query users (phân trang)
        Page<User> userPage = userRepository.findAll(spec, pageable);

        // 4. Lấy tất cả profile của trang hiện tại trong 1 query (tránh N+1)
        List<Long> userIds = userPage.getContent().stream()
                .map(User::getId)
                .collect(Collectors.toList());

        Map<Long, UserProfile> profileMap = userProfileRepository.findAllByUserIdIn(userIds)
                .stream()
                .collect(Collectors.toMap(
                        p -> p.getUser().getId(),
                        p -> p
                ));

        // 5. Map sang DTO, kết hợp user + profile
        return userPage.map(user -> UserResponse.fromEntity(user, profileMap.get(user.getId()), user.getTeacherProfile()));
    }

    // ============================================================
    // XEM CHI TIẾT NGƯỜI DÙNG
    // ============================================================
    public UserResponse getUserById(Long id) {

        // 1. Tìm user theo id, chưa bị xóa mềm
        User user = userRepository.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new CustomException(
                        HttpStatus.NOT_FOUND,
                        "Không tìm thấy người dùng với id: " + id
                ));

        // 2. Lấy profile (có thể null nếu chưa có)
        UserProfile profile = userProfileRepository.findByUserId(id).orElse(null);

        // 3. Map sang DTO
        return UserResponse.fromEntity(user, profile, user.getTeacherProfile());
    }

    // ============================================================
    // SPECIFICATION (dynamic filter cho danh sách)
    // ============================================================
    private Specification<User> buildSpecification(UserListRequest request) {
        return (root, query, cb) -> {

            query.distinct(true);

            var predicates = new java.util.ArrayList<jakarta.persistence.criteria.Predicate>();

            // Filter theo keyword: username, email, full_name
            if (request.getKeyword() != null && !request.getKeyword().isBlank()) {
                String pattern = "%" + request.getKeyword().trim().toLowerCase() + "%";
                Join<Object, Object> profileJoin = root.join("profile", JoinType.LEFT);
                predicates.add(cb.or(
                        cb.like(cb.lower(root.get("username")), pattern),
                        cb.like(cb.lower(root.get("email")), pattern),
                        cb.like(cb.lower(profileJoin.get("fullName")), pattern)
                ));
            }

            // Filter theo isActive
            if (request.getIsActive() != null) {
                predicates.add(cb.equal(root.get("isActive"), request.getIsActive()));
            }

            // Filter theo roleCode
            if (request.getRoleCode() != null && !request.getRoleCode().isBlank()) {
                Join<Object, Object> rolesJoin = root.join("roles", JoinType.INNER);
                predicates.add(cb.equal(rolesJoin.get("code"), request.getRoleCode().toUpperCase()));
            }

            // Filter theo majorId (JOIN: users -> student_profiles -> majors)
            // Chỉ có ý nghĩa với STUDENT vì chỉ student_profiles mới có major_id
            if (request.getMajorId() != null) {
                Join<Object, Object> studentProfileJoin = root.join("studentProfile", JoinType.INNER);
                predicates.add(cb.equal(studentProfileJoin.get("major").get("id"), request.getMajorId()));
            }

            // Filter theo departmentId — 2 nhánh JOIN khác nhau tùy role:
//   STUDENT:    users -> student_profiles -> majors -> departments
//   INSTRUCTOR: users -> teacher_profiles -> departments
            if (request.getDepartmentId() != null) {
                // Nhánh STUDENT
                var studentProfileJoin = root.join("studentProfile", JoinType.LEFT);
                var majorJoin = studentProfileJoin.join("major", JoinType.LEFT);
                var studentDeptPredicate = cb.equal(
                        majorJoin.get("department").get("id"),
                        request.getDepartmentId()
                );

                // Nhánh INSTRUCTOR
                var teacherProfileJoin = root.join("teacherProfile", JoinType.LEFT);
                var teacherDeptPredicate = cb.equal(
                        teacherProfileJoin.get("department").get("id"),
                        request.getDepartmentId()
                );

                // Thỏa một trong hai nhánh là match
                predicates.add(cb.or(studentDeptPredicate, teacherDeptPredicate));
            }// Filter theo departmentId — 2 nhánh JOIN khác nhau tùy role:
//   STUDENT:    users -> student_profiles -> majors -> departments
//   INSTRUCTOR: users -> teacher_profiles -> departments
            if (request.getDepartmentId() != null) {
                // Nhánh STUDENT
                var studentProfileJoin = root.join("studentProfile", JoinType.LEFT);
                var majorJoin = studentProfileJoin.join("major", JoinType.LEFT);
                var studentDeptPredicate = cb.equal(
                        majorJoin.get("department").get("id"),
                        request.getDepartmentId()
                );

                // Nhánh INSTRUCTOR
                var teacherProfileJoin = root.join("teacherProfile", JoinType.LEFT);
                var teacherDeptPredicate = cb.equal(
                        teacherProfileJoin.get("department").get("id"),
                        request.getDepartmentId()
                );

                // Thỏa một trong hai nhánh là match
                predicates.add(cb.or(studentDeptPredicate, teacherDeptPredicate));
            }


            // Chỉ lấy user chưa bị xóa mềm
            predicates.add(cb.isNull(root.get("deletedAt")));

            return cb.and(predicates.toArray(new jakarta.persistence.criteria.Predicate[0]));
        };
    }
}