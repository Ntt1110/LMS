package com.example.LMS.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CourseApproveRequest {

    @NotNull(message = "ID môn học không được để trống")
    private Long courseId;
}